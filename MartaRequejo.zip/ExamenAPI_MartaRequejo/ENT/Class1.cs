﻿namespace ENT
{
    public class Class1
    {

        #region Propiedades

        #endregion

        #region Atributos

        #endregion

        #region Constructores

        #endregion

    }
}
